
public class Node {

    NodeData data;
    Node left, right;



}

