public class NodeData {
    String w;
    int count;



    public void visit() {
        System.out.print(w + " ");
    }


}